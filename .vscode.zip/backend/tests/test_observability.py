"""Verify privacy-safe structured traces and the development trace endpoint."""

import json

import pytest
from fastapi import HTTPException

from backend.app.api.routes.observability import read_analysis_trace
from backend.app.observability import (
    bind_trace,
    configure_observability,
    get_trace,
    log_event,
    reset_trace,
    sql_fingerprint,
    trace_log_path,
)


def test_structured_trace_redacts_secret_fields_and_keeps_safe_metadata(tmp_path):
    """Write one event and retain diagnostics without storing supplied secrets."""
    path = configure_observability(tmp_path / "analysis.jsonl")
    trace_id = "a" * 32
    token = bind_trace(trace_id)
    try:
        log_event(
            "planner.completed",
            relevant_tables=["customers", "orders"],
            password="not-for-logs",
            api_key="also-secret",
        )
    finally:
        reset_trace(token)

    for handler in __import__("logging").getLogger("analyst_ai.observability").handlers:
        handler.flush()
    record = json.loads(path.read_text(encoding="utf-8").splitlines()[-1])
    assert record["trace_id"] == trace_id
    assert record["relevant_tables"] == ["customers", "orders"]
    assert record["password"] == "[REDACTED]"
    assert record["api_key"] == "[REDACTED]"
    assert "not-for-logs" not in path.read_text(encoding="utf-8")
    individual_path = trace_log_path(trace_id)
    assert individual_path == tmp_path / "traces" / f"{trace_id}.jsonl"
    assert individual_path.exists()
    individual_record = json.loads(
        individual_path.read_text(encoding="utf-8").splitlines()[-1]
    )
    assert individual_record["event"] == "planner.completed"
    assert individual_record["password"] == "[REDACTED]"


def test_each_analysis_trace_gets_a_separate_jsonl_file(tmp_path):
    """Keep complete event sequences isolated by trace ID on disk."""
    configure_observability(tmp_path / "analysis.jsonl")
    trace_ids = ("c" * 32, "d" * 32)
    for trace_id in trace_ids:
        token = bind_trace(trace_id)
        try:
            log_event("http.request.started", path="/api/v1/analyze")
            log_event("catalog.started")
            log_event("analysis.completed", outcome="direct_answer")
        finally:
            reset_trace(token)

    paths = [trace_log_path(trace_id) for trace_id in trace_ids]
    assert paths[0] != paths[1]
    assert all(path.exists() for path in paths)
    for path, trace_id in zip(paths, trace_ids, strict=True):
        records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
        assert [record["event"] for record in records] == [
            "http.request.started",
            "catalog.started",
            "analysis.completed",
        ]
        assert {record["trace_id"] for record in records} == {trace_id}


def test_development_trace_endpoint_returns_only_the_bounded_safe_trace(monkeypatch):
    """Return a known trace in development and hide trace access in production."""
    trace_id = "b" * 32
    token = bind_trace(trace_id)
    try:
        log_event("policy.selected", action="execute_query")
    finally:
        reset_trace(token)

    response = read_analysis_trace(trace_id)
    assert response["trace_id"] == trace_id
    assert response["events"][-1]["action"] == "execute_query"

    monkeypatch.setenv("APP_ENV", "production")
    with pytest.raises(HTTPException) as error:
        read_analysis_trace(trace_id)
    assert error.value.status_code == 404


def test_sql_fingerprint_is_stable_without_containing_raw_sql():
    """Create the same compact fingerprint for whitespace-only SQL differences."""
    first = sql_fingerprint("SELECT region FROM customers")
    second = sql_fingerprint("  SELECT   region  FROM customers  ")
    assert first == second
    assert "region" not in first
