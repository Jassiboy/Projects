"""Verify that Python, rather than the LLM, selects every allowed workflow action."""

import pytest

from backend.app.analysis.models import SQLPlan
from backend.app.tools.policy import DeterministicToolPolicy, WorkflowAction


@pytest.mark.parametrize(
    ("plan", "expected"),
    [
        (SQLPlan(intent="Ambiguous", clarification_question="Which revenue?"), WorkflowAction.ASK_CLARIFICATION),
        (SQLPlan(intent="Explain", direct_answer="Net revenue subtracts refunds."), WorkflowAction.RETURN_DIRECT),
        (SQLPlan(intent="Query", sql="SELECT 1"), WorkflowAction.EXECUTE_QUERY),
        (SQLPlan(intent="Incomplete"), WorkflowAction.REJECT),
    ],
)
def test_policy_selects_only_allow_listed_actions(plan, expected):
    """Return the single deterministic action allowed for each typed plan shape."""
    assert DeterministicToolPolicy().decide(plan).action is expected


def test_sql_cannot_bypass_clarification_priority():
    """Require clarification even when an ambiguous LLM plan also includes SQL."""
    plan = SQLPlan(
        intent="Ambiguous revenue",
        clarification_question="Do you mean gross or net revenue?",
        sql="SELECT SUM(amount) FROM payments",
    )
    assert DeterministicToolPolicy().decide(plan).action is WorkflowAction.ASK_CLARIFICATION
