"""Verify plug-and-play simulation without MySQL or an external LLM."""

from fastapi.testclient import TestClient

from backend.app.main import create_app
from backend.app.simulation.fake_database import FakeDatabaseAdapter
from backend.app.simulation.fake_llm import FakeLLMProvider
from backend.app.analysis.models import SQLPlan


def test_fake_database_exposes_production_shaped_catalog_and_queries():
    """The fake adapter provides seven tables and executes MySQL-shaped reads."""
    adapter = FakeDatabaseAdapter(latency_ms=0)
    try:
        assert adapter.health_check() is True
        assert len(adapter.list_tables()) == 7
        tables, columns, relationships = adapter.load_catalog_metadata()
        assert {row["table_name"] for row in tables} == {
            "categories",
            "customers",
            "order_items",
            "orders",
            "payments",
            "products",
            "refunds",
        }
        assert columns
        assert relationships
        result = adapter.execute_query(
            "SELECT region, COUNT(*) AS customer_count "
            "FROM customers GROUP BY region ORDER BY region",
            row_limit=100,
        )
        assert result.row_count == 5
        assert result.columns == ["region", "customer_count"]
    finally:
        adapter.close()


def test_fake_llm_returns_typed_region_revenue_plan():
    """The fake provider returns a typed deterministic plan with validated tables."""
    provider = FakeLLMProvider(latency_ms=0)
    response = provider.generate_structured(
        "User question:\nGive the revenue region-wise\n\n"
        "Additional repair context:\n",
        SQLPlan,
    )
    assert response.provider_name == "simulation"
    assert response.parsed_output.relevant_tables == [
        "customers",
        "orders",
        "payments",
        "refunds",
    ]
    assert "GROUP BY c.region" in response.parsed_output.sql


def test_simulation_api_runs_success_clarification_repair_and_rejection(monkeypatch):
    """The real API and workflow use fake boundaries while preserving all policies."""
    monkeypatch.setenv("APP_ENV", "development")
    monkeypatch.setenv("SIMULATION_MODE", "false")
    monkeypatch.setenv("SIMULATION_LATENCY_MS", "0")
    app = create_app()
    client = TestClient(app)
    mode = client.get("/api/v1/database/mode")
    assert mode.status_code == 200
    assert mode.json() == {"available": True, "default_enabled": False}

    connection = client.post("/api/v1/database/simulation/connect")
    assert connection.status_code == 200
    session = connection.json()
    assert session["simulation"] is True
    assert session["engine"] == "Local simulation"
    headers = {"X-Database-Connection": session["connection_id"]}

    region = client.post(
        "/api/v1/analyze",
        headers=headers,
        json={"question": "Give the revenue region-wise"},
    )
    assert region.status_code == 200
    assert len(region.json()["rows"]) == 5
    assert region.json()["chart"]["chart_type"] == "bar"
    assert "GROUP BY c.region" in region.json()["sql"]

    direct = client.post(
        "/api/v1/analyze",
        headers=headers,
        json={"question": "What does net revenue mean?"},
    )
    assert direct.status_code == 200
    assert direct.json()["sql"] is None

    clarification = client.post(
        "/api/v1/analyze",
        headers=headers,
        json={"question": "Show revenue"},
    )
    assert clarification.status_code == 200
    assert clarification.json()["needs_clarification"] is True

    repaired = client.post(
        "/api/v1/analyze",
        headers=headers,
        json={"question": "Simulate repair"},
    )
    assert repaired.status_code == 200
    assert repaired.json()["execution_metadata"]["attempts"] == 2

    unsafe = client.post(
        "/api/v1/analyze",
        headers=headers,
        json={"question": "Simulate unsafe SQL"},
    )
    assert unsafe.status_code == 200
    assert unsafe.json()["rows"] == []
    assert unsafe.json()["warnings"]
