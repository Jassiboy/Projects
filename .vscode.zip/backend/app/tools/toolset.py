"""Bundle typed analysis capabilities that only the workflow may invoke."""

from dataclasses import dataclass
from typing import Any

from backend.app.analysis.answer_builder import AnswerBuilder
from backend.app.analysis.chart_policy import ChartPolicy
from backend.app.analysis.models import AnalysisResult, ChartSpec, SQLPlan
from backend.app.database.safe_query_runner import SafeQueryResult, SafeQueryRunner
from backend.app.database.sql_validator import SQLValidationResult, SQLValidator


@dataclass(frozen=True)
class AnalysisToolset:
    """Provide the workflow's allow-listed validation, query, chart, and answer tools."""

    validator: SQLValidator
    query_runner: SafeQueryRunner
    answer_builder: AnswerBuilder
    chart_policy: ChartPolicy

    def validate_sql(self, sql: str, row_limit: int) -> SQLValidationResult:
        """Validate one read-only SQL statement and return its normalized result."""
        return self.validator.validate(sql, row_limit=row_limit)

    def execute_sql(self, sql: str, row_limit: int) -> SafeQueryResult:
        """Execute validated SQL through the bounded query runner and return rows."""
        return self.query_runner.run(sql, row_limit=row_limit)

    def choose_chart(
        self,
        plan: SQLPlan,
        columns: list[str],
        rows: list[dict[str, Any]],
    ) -> ChartSpec:
        """Apply deterministic chart policy and return a safe visualization spec."""
        return self.chart_policy.build_spec(plan, columns, rows)

    def build_answer(
        self,
        question: str,
        plan: SQLPlan,
        validated_sql: str,
        rows: list[dict[str, Any]],
        chart_spec: ChartSpec | None,
    ) -> AnalysisResult:
        """Build a grounded narrative answer from the already executed query rows."""
        return self.answer_builder.build(
            question, plan, validated_sql, rows, chart_spec
        )
