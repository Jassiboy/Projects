"""Choose the next workflow action in Python without autonomous LLM tool calls."""

from dataclasses import dataclass
from enum import Enum

from backend.app.analysis.models import SQLPlan


class WorkflowAction(str, Enum):
    """List the only actions the analysis workflow is allowed to perform."""

    ASK_CLARIFICATION = "ask_clarification"
    RETURN_DIRECT = "return_direct"
    EXECUTE_QUERY = "execute_query"
    REJECT = "reject"


@dataclass(frozen=True)
class ToolDecision:
    """Return the Python-selected action and a safe reason for audit logs or errors."""

    action: WorkflowAction
    reason: str


class DeterministicToolPolicy:
    """Map a typed LLM plan to an allow-listed action using deterministic rules."""

    def decide(self, plan: SQLPlan) -> ToolDecision:
        """Select one allowed action; never accept an LLM-provided tool name."""
        if plan.clarification_question:
            return ToolDecision(
                WorkflowAction.ASK_CLARIFICATION,
                "The plan requires user clarification before execution.",
            )
        if plan.direct_answer is not None and not plan.sql.strip():
            return ToolDecision(
                WorkflowAction.RETURN_DIRECT,
                "The plan can be answered without database access.",
            )
        if plan.sql.strip():
            return ToolDecision(
                WorkflowAction.EXECUTE_QUERY,
                "The plan contains SQL that must pass deterministic validation.",
            )
        return ToolDecision(
            WorkflowAction.REJECT,
            "The plan contains no safe executable action.",
        )
