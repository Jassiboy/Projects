# Local simulation mode

Simulation mode replaces both external boundaries while preserving the real workflow:

- `FakeLLMProvider` returns typed plans, repair plans, direct answers, clarifications, and controlled failures.
- `FakeDatabaseAdapter` uses a seeded in-memory database with the same seven business tables.
- The real catalog loader, glossary, Python tool policy, SQL validator, query runner, chart policy, answer grounding, API, UI, and observability still run.

## Use it from the UI

Start Uvicorn normally. In development, the header shows a **Live / Simulation** switch.

- Turn **Simulation** on: a fake database session starts immediately, with no credentials, MySQL connection, or Gemini request.
- Turn it off: the app returns to **Live** and opens the MySQL credential dialog.

## Choose the startup default

Add this to `.env` and restart Uvicorn:

```env
SIMULATION_MODE=true
SIMULATION_LATENCY_MS=180
```

Set `SIMULATION_MODE=false` to start in Live mode. The UI switch still remains available during development.

## Suggested prompts

### Successful paths

1. `Give the revenue region-wise`
2. `Compare net revenue year by year`
3. `Show net revenue by sales channel`
4. `Show the top 5 products by sales`
5. `Count customers by region`
6. `Show orders by status`
7. `What is the total net revenue?`
8. `What is the refund rate?`

### Workflow behavior

9. `What does net revenue mean?` — direct answer, no SQL.
10. `Show revenue` — clarification, no SQL.
11. `Show revenue for Antarctica` — empty result.
12. `Simulate repair` — first database execution fails; controlled repair succeeds.
13. `Simulate unsafe SQL` — validator rejects a write query.
14. `Simulate database failure` — execution fails and repair is attempted.
15. `Simulate rate limit` — LLM rate-limit handling.
16. `Simulate LLM timeout` — LLM timeout handling.
17. `Simulate invalid LLM` — malformed provider-response handling.

Run `python backend/scripts/show_simulation_prompts.py` to print this guide.
