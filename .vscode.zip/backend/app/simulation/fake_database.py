"""Simulate the analytics database in memory while preserving the adapter contract."""

from __future__ import annotations

import sqlite3
import threading
import time
from collections.abc import Sequence
from typing import Any

from sqlglot import transpile
from sqlglot.errors import SqlglotError

from backend.app.database.base import (
    DatabaseAdapter,
    DatabaseConnectionError,
    DatabaseQueryError,
    QueryTimeoutError,
)
from backend.app.database.models import ColumnInfo, QueryResult, TableInfo, TableSchema


class FakeDatabaseAdapter(DatabaseAdapter):
    """Run deterministic analytics against an isolated seeded SQLite database."""

    database_name = "analyst_ai_simulation"

    def __init__(self, latency_ms: int = 40) -> None:
        """Create, seed, and retain one thread-safe in-memory database."""
        self._latency_seconds = max(latency_ms, 0) / 1000
        self._lock = threading.RLock()
        self._closed = False
        self._connection = sqlite3.connect(":memory:", check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA foreign_keys = ON")
        self._create_schema()
        self._seed_data()

    def health_check(self) -> bool:
        """Return true when the in-memory database accepts a simple read."""
        self._ensure_open()
        row = self._connection.execute("SELECT 1").fetchone()
        return bool(row and row[0] == 1)

    def list_tables(self) -> list[TableInfo]:
        """Return the same seven business tables exposed by the real MySQL demo."""
        self._ensure_open()
        rows = self._connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name"
        ).fetchall()
        return [TableInfo(name=row[0], table_type="BASE TABLE") for row in rows]

    def get_table_schema(self, table_name: str) -> TableSchema:
        """Return SQLite column metadata in the application's neutral schema model."""
        self._ensure_open()
        if table_name not in {table.name for table in self.list_tables()}:
            raise DatabaseQueryError(f"Table '{table_name}' was not found")
        rows = self._connection.execute(f"PRAGMA table_info({table_name})").fetchall()
        return TableSchema(
            name=table_name,
            columns=[
                ColumnInfo(
                    name=row[1],
                    data_type=row[2].casefold(),
                    nullable=not bool(row[3]),
                    key="PRI" if row[5] else None,
                    default=row[4],
                    extra="",
                )
                for row in rows
            ],
        )

    def load_catalog_metadata(
        self,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        """Return deterministic table, column, and foreign-key rows for catalog loading."""
        table_rows = [
            {"table_name": table.name, "description": "Simulation table"}
            for table in self.list_tables()
        ]
        column_rows: list[dict[str, Any]] = []
        relationship_rows: list[dict[str, Any]] = []
        for table in self.list_tables():
            for column in self.get_table_schema(table.name).columns:
                column_rows.append(
                    {
                        "table_name": table.name,
                        "column_name": column.name,
                        "data_type": column.data_type,
                        "nullable": "YES" if column.nullable else "NO",
                        "column_key": column.key or "",
                        "description": "",
                    }
                )
            for foreign_key in self._connection.execute(
                f"PRAGMA foreign_key_list({table.name})"
            ).fetchall():
                relationship_rows.append(
                    {
                        "constraint_name": f"fk_{table.name}_{foreign_key[3]}",
                        "source_table": table.name,
                        "source_column": foreign_key[3],
                        "target_table": foreign_key[2],
                        "target_column": foreign_key[4],
                        "ordinal_position": 1,
                    }
                )
        return table_rows, column_rows, relationship_rows

    def execute_query(
        self,
        sql: str,
        parameters: Sequence[Any] | None = None,
        row_limit: int = 100,
        timeout_seconds: float | None = None,
    ) -> QueryResult:
        """Transpile validated MySQL SQL, execute it locally, and return bounded rows."""
        self._ensure_open()
        if "simulate_transient_failure" in sql.casefold():
            raise DatabaseQueryError("Simulated transient database failure")
        if timeout_seconds is not None and self._latency_seconds > timeout_seconds:
            raise QueryTimeoutError("Simulated database timeout")
        started_at = time.perf_counter()
        if self._latency_seconds:
            time.sleep(self._latency_seconds)
        try:
            sqlite_sql = transpile(sql, read="mysql", write="sqlite")[0]
            with self._lock:
                cursor = self._connection.execute(sqlite_sql, tuple(parameters or ()))
                columns = [description[0] for description in cursor.description or ()]
                fetched = cursor.fetchmany(row_limit + 1)
        except (sqlite3.Error, SqlglotError, IndexError) as error:
            raise DatabaseQueryError("Simulated query execution failed") from error
        truncated = len(fetched) > row_limit
        rows = [dict(row) for row in fetched[:row_limit]]
        return QueryResult(
            columns=columns,
            rows=rows,
            row_count=len(rows),
            execution_time=time.perf_counter() - started_at,
            truncated=truncated,
            executed_sql=sql,
        )

    def close(self) -> None:
        """Close the in-memory connection and reject future operations."""
        with self._lock:
            if not self._closed:
                self._connection.close()
                self._closed = True

    def _ensure_open(self) -> None:
        """Raise a neutral connection error after the adapter has been closed."""
        if self._closed:
            raise DatabaseConnectionError("Simulation database is closed")

    def _create_schema(self) -> None:
        """Create the seven production-shaped tables used by the simulator."""
        self._connection.executescript(
            """
            CREATE TABLE categories (
                category_id INTEGER PRIMARY KEY,
                category_name TEXT NOT NULL
            );
            CREATE TABLE customers (
                customer_id INTEGER PRIMARY KEY,
                customer_name TEXT NOT NULL,
                email TEXT NOT NULL,
                city TEXT NOT NULL,
                state TEXT NOT NULL,
                region TEXT NOT NULL,
                signup_date TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE products (
                product_id INTEGER PRIMARY KEY,
                product_name TEXT NOT NULL,
                category_id INTEGER NOT NULL REFERENCES categories(category_id),
                unit_price REAL NOT NULL,
                cost_price REAL NOT NULL,
                is_active INTEGER NOT NULL
            );
            CREATE TABLE orders (
                order_id INTEGER PRIMARY KEY,
                customer_id INTEGER NOT NULL REFERENCES customers(customer_id),
                order_date TEXT NOT NULL,
                order_status TEXT NOT NULL,
                sales_channel TEXT NOT NULL,
                shipping_amount REAL NOT NULL,
                discount_amount REAL NOT NULL
            );
            CREATE TABLE order_items (
                order_item_id INTEGER PRIMARY KEY,
                order_id INTEGER NOT NULL REFERENCES orders(order_id),
                product_id INTEGER NOT NULL REFERENCES products(product_id),
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                discount_amount REAL NOT NULL
            );
            CREATE TABLE payments (
                payment_id INTEGER PRIMARY KEY,
                order_id INTEGER NOT NULL REFERENCES orders(order_id),
                payment_date TEXT NOT NULL,
                payment_method TEXT NOT NULL,
                payment_status TEXT NOT NULL,
                amount REAL NOT NULL
            );
            CREATE TABLE refunds (
                refund_id INTEGER PRIMARY KEY,
                order_id INTEGER NOT NULL REFERENCES orders(order_id),
                order_item_id INTEGER REFERENCES order_items(order_item_id),
                refund_date TEXT NOT NULL,
                refund_amount REAL NOT NULL,
                refund_reason TEXT NOT NULL
            );
            """
        )

    def _seed_data(self) -> None:
        """Insert repeatable multi-year, multi-region data for charts and edge cases."""
        categories = [(1, "Electronics"), (2, "Home"), (3, "Sports"), (4, "Books")]
        products = [
            (1, "Wireless Headphones", 1, 120.0, 72.0, 1),
            (2, "Smart Speaker", 1, 90.0, 50.0, 1),
            (3, "Coffee Maker", 2, 80.0, 42.0, 1),
            (4, "Desk Lamp", 2, 45.0, 20.0, 1),
            (5, "Yoga Mat", 3, 35.0, 14.0, 1),
            (6, "Running Shoes", 3, 110.0, 55.0, 1),
            (7, "Data Storytelling", 4, 40.0, 15.0, 1),
            (8, "SQL Handbook", 4, 55.0, 18.0, 1),
        ]
        regions = ["Northeast", "Southeast", "Midwest", "Southwest", "West"]
        customers = [
            (
                index,
                f"Demo Customer {index}",
                f"demo{index}@example.invalid",
                f"Demo City {index}",
                "Demo State",
                regions[(index - 1) % len(regions)],
                f"202{(index - 1) % 4 + 1}-01-15",
                f"202{(index - 1) % 4 + 1}-01-15 09:00:00",
            )
            for index in range(1, 11)
        ]
        self._connection.executemany("INSERT INTO categories VALUES (?, ?)", categories)
        self._connection.executemany("INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)", products)
        self._connection.executemany(
            "INSERT INTO customers VALUES (?, ?, ?, ?, ?, ?, ?, ?)", customers
        )

        channels = ["online", "in_store", "marketplace", "mobile"]
        methods = ["credit_card", "debit_card", "digital_wallet", "bank_transfer"]
        orders: list[tuple[Any, ...]] = []
        items: list[tuple[Any, ...]] = []
        payments: list[tuple[Any, ...]] = []
        refunds: list[tuple[Any, ...]] = []
        item_id = payment_id = refund_id = 1
        for order_id in range(1, 33):
            year = 2022 + (order_id - 1) % 4
            month = 1 + (order_id * 3) % 12
            customer_id = 1 + (order_id - 1) % 10
            status = "payment_failed" if order_id % 8 == 0 else "completed"
            order_date = f"{year}-{month:02d}-{1 + order_id % 24:02d} 10:00:00"
            orders.append(
                (order_id, customer_id, order_date, status, channels[order_id % 4], 8.0, 5.0)
            )
            product_id = 1 + (order_id - 1) % len(products)
            quantity = 1 + order_id % 3
            amount = round(products[product_id - 1][3] * quantity - 5.0 + 8.0, 2)
            items.append((item_id, order_id, product_id, quantity, products[product_id - 1][3], 5.0))
            payments.append(
                (
                    payment_id,
                    order_id,
                    order_date,
                    methods[order_id % 4],
                    "successful" if status == "completed" else "failed",
                    amount,
                )
            )
            if status == "completed" and order_id % 5 == 0:
                refunds.append(
                    (
                        refund_id,
                        order_id,
                        item_id,
                        f"{year}-{month:02d}-{2 + order_id % 24:02d} 10:00:00",
                        round(amount * 0.25, 2),
                        "Simulation refund",
                    )
                )
                refund_id += 1
            item_id += 1
            payment_id += 1
        self._connection.executemany("INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?, ?)", orders)
        self._connection.executemany("INSERT INTO order_items VALUES (?, ?, ?, ?, ?, ?)", items)
        self._connection.executemany("INSERT INTO payments VALUES (?, ?, ?, ?, ?, ?)", payments)
        self._connection.executemany("INSERT INTO refunds VALUES (?, ?, ?, ?, ?, ?)", refunds)
        self._connection.commit()
