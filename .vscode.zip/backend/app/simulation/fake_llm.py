"""Simulate structured LLM planning, repair, errors, and grounded answers."""

from __future__ import annotations

import time

from pydantic import BaseModel

from backend.app.analysis.answer_builder import GroundedAnswer
from backend.app.analysis.models import ChartSuggestion, SQLPlan
from backend.app.llm.base import (
    LLMProvider,
    LLMRateLimitError,
    LLMResponseError,
    LLMTimeoutError,
    ResponseModel,
)
from backend.app.llm.models import LLMResponse, TokenUsage
from backend.app.observability import capture_llm_payloads_enabled, log_event


_NET_REVENUE_CTES = """
WITH paid AS (
    SELECT o.order_id, o.customer_id, o.order_date, o.sales_channel,
           SUM(p.amount) AS paid_amount
    FROM orders AS o
    JOIN payments AS p ON p.order_id = o.order_id
    WHERE p.payment_status = 'successful'
    GROUP BY o.order_id, o.customer_id, o.order_date, o.sales_channel
), refunded AS (
    SELECT order_id, SUM(refund_amount) AS refund_amount
    FROM refunds
    GROUP BY order_id
)
""".strip()


class FakeLLMProvider(LLMProvider):
    """Return repeatable typed responses for analytics and failure scenarios."""

    def __init__(self, latency_ms: int = 180) -> None:
        """Configure a small delay so UI progress remains observable."""
        self._latency_seconds = max(latency_ms, 0) / 1000

    def generate_structured(
        self,
        prompt: str,
        response_model: type[ResponseModel],
    ) -> LLMResponse[ResponseModel]:
        """Generate a deterministic plan or grounded answer."""
        started_at = time.perf_counter()
        question = self._extract_question(prompt)
        lowered = question.casefold()
        if capture_llm_payloads_enabled():
            log_event(
                "llm.request.payload",
                provider="simulation",
                response_model=response_model.__name__,
                prompt=prompt,
            )
        if self._latency_seconds:
            time.sleep(self._latency_seconds)
        if "simulate rate limit" in lowered:
            raise LLMRateLimitError("Simulated rate limit")
        if "simulate llm timeout" in lowered:
            raise LLMTimeoutError("Simulated LLM timeout")
        if "simulate invalid llm" in lowered:
            raise LLMResponseError("Simulated invalid structured response")

        parsed: BaseModel
        if response_model is SQLPlan:
            parsed = self._plan(question, prompt)
        elif response_model is GroundedAnswer:
            parsed = GroundedAnswer(
                explanation=(
                    "The simulated query completed and the returned values "
                    "are shown below."
                ),
                findings=[],
                evidence=[],
            )
        else:
            raise LLMResponseError(
                f"Simulation does not implement {response_model.__name__}"
            )

        latency = time.perf_counter() - started_at
        output_json = parsed.model_dump_json()
        if capture_llm_payloads_enabled():
            log_event(
                "llm.response.payload",
                provider="simulation",
                model="deterministic-local-v1",
                response_model=response_model.__name__,
                latency_ms=round(latency * 1000, 3),
                finish_status="stop",
                input_tokens=max(1, len(prompt) // 4),
                output_tokens=max(1, len(output_json) // 4),
                structured_response_json=output_json,
            )
        return LLMResponse(
            parsed_output=parsed,  # type: ignore[arg-type]
            provider_name="simulation",
            model_name="deterministic-local-v1",
            latency_seconds=latency,
            token_usage=TokenUsage(
                input_tokens=max(1, len(prompt) // 4),
                output_tokens=max(1, len(output_json) // 4),
            ),
            finish_status="stop",
        )

    @staticmethod
    def _extract_question(prompt: str) -> str:
        """Extract the user question from planner, repair, or answer prompts."""
        for marker, terminator in (
            ("User question:\n", "\n\nAdditional repair context:"),
            ("Question:\n", "\n\nAssumptions:"),
        ):
            if marker in prompt:
                tail = prompt.split(marker, 1)[1]
                return tail.split(terminator, 1)[0].strip()
        return prompt.strip()

    def _plan(self, question: str, prompt: str) -> SQLPlan:
        """Map supported questions to production-shaped plans and failures."""
        text = question.casefold()
        is_repair = "Previous SQL:" in prompt
        if "simulate repair" in text:
            if not is_repair:
                return SQLPlan(
                    intent="Demonstrate controlled database repair",
                    relevant_tables=["orders"],
                    sql="SELECT COUNT(*) AS simulate_transient_failure FROM orders",
                )
            return SQLPlan(
                intent="Recovered order count",
                relevant_tables=["orders"],
                sql="SELECT COUNT(*) AS order_count FROM orders",
            )
        if "simulate unsafe sql" in text:
            return SQLPlan(
                intent="Demonstrate SQL rejection",
                relevant_tables=["orders"],
                sql="DELETE FROM orders",
            )
        if "simulate database failure" in text:
            return SQLPlan(
                intent="Demonstrate database failure",
                relevant_tables=["orders"],
                sql="SELECT COUNT(*) AS simulate_transient_failure FROM orders",
            )
        if "no matching data" in text or "antarctica" in text:
            return SQLPlan(
                intent="Empty result demonstration",
                relevant_tables=["customers"],
                sql=(
                    "SELECT region, COUNT(*) AS customer_count FROM customers "
                    "WHERE region = 'Antarctica' GROUP BY region"
                ),
            )
        if "what does net revenue" in text or "define net revenue" in text:
            return SQLPlan(
                intent="Explain the net revenue metric",
                direct_answer=(
                    "Net revenue is successful payment amount minus refunded amount. "
                    "Payments and refunds must be aggregated separately to avoid join fan-out."
                ),
            )
        if text.strip() in {"show revenue", "revenue", "compare revenue"}:
            return SQLPlan(
                intent="Clarify the requested revenue metric",
                clarification_question=(
                    "Do you want gross successful-payment revenue or net revenue after refunds?"
                ),
            )
        if "refund rate" in text:
            return SQLPlan(
                intent="Refund rate",
                relevant_tables=["payments", "refunds"],
                sql=(
                    "WITH paid AS (SELECT SUM(amount) AS paid_amount FROM payments "
                    "WHERE payment_status = 'successful'), refunded AS "
                    "(SELECT SUM(refund_amount) AS refund_amount FROM refunds) "
                    "SELECT ROUND(COALESCE(refunded.refund_amount, 0) / "
                    "NULLIF(paid.paid_amount, 0), 4) AS refund_rate "
                    "FROM paid CROSS JOIN refunded"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="kpi", title="Refund rate", y_field="refund_rate"
                ),
            )
        if "top" in text and "product" in text:
            return SQLPlan(
                intent="Top products by sales",
                relevant_tables=["products", "order_items", "orders"],
                sql=(
                    "SELECT pr.product_name, ROUND(SUM(oi.quantity * oi.unit_price "
                    "- oi.discount_amount), 2) AS sales_amount "
                    "FROM order_items AS oi JOIN products AS pr "
                    "ON pr.product_id = oi.product_id JOIN orders AS o "
                    "ON o.order_id = oi.order_id WHERE o.order_status = 'completed' "
                    "GROUP BY pr.product_name ORDER BY sales_amount DESC LIMIT 5"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="bar",
                    title="Top products",
                    x_field="product_name",
                    y_field="sales_amount",
                ),
            )
        if "customer" in text and "region" in text:
            return SQLPlan(
                intent="Customers by region",
                relevant_tables=["customers"],
                sql=(
                    "SELECT region, COUNT(*) AS customer_count FROM customers "
                    "GROUP BY region ORDER BY customer_count DESC"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="bar",
                    title="Customers by region",
                    x_field="region",
                    y_field="customer_count",
                ),
            )
        if "order status" in text or "orders by status" in text:
            return SQLPlan(
                intent="Orders by status",
                relevant_tables=["orders"],
                sql=(
                    "SELECT order_status, COUNT(*) AS order_count FROM orders "
                    "GROUP BY order_status ORDER BY order_count DESC"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="bar",
                    title="Orders by status",
                    x_field="order_status",
                    y_field="order_count",
                ),
            )
        if "channel" in text and "revenue" in text:
            return SQLPlan(
                intent="Net revenue by sales channel",
                relevant_tables=["orders", "payments", "refunds"],
                sql=(
                    f"{_NET_REVENUE_CTES} SELECT paid.sales_channel, "
                    "ROUND(SUM(paid.paid_amount - COALESCE(refunded.refund_amount, 0)), "
                    "2) AS net_revenue FROM paid LEFT JOIN refunded "
                    "ON refunded.order_id = paid.order_id GROUP BY paid.sales_channel "
                    "ORDER BY net_revenue DESC"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="bar",
                    title="Net revenue by channel",
                    x_field="sales_channel",
                    y_field="net_revenue",
                ),
            )
        if ("year" in text or "yearly" in text) and "revenue" in text:
            return SQLPlan(
                intent="Net revenue by year",
                relevant_tables=["orders", "payments", "refunds"],
                sql=(
                    f"{_NET_REVENUE_CTES} SELECT YEAR(paid.order_date) AS revenue_year, "
                    "ROUND(SUM(paid.paid_amount - COALESCE(refunded.refund_amount, 0)), "
                    "2) AS net_revenue FROM paid LEFT JOIN refunded "
                    "ON refunded.order_id = paid.order_id GROUP BY YEAR(paid.order_date) "
                    "ORDER BY revenue_year"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="line",
                    title="Net revenue by year",
                    x_field="revenue_year",
                    y_field="net_revenue",
                ),
            )
        if "region" in text and "revenue" in text:
            return SQLPlan(
                intent="Net revenue by region",
                relevant_tables=["customers", "orders", "payments", "refunds"],
                sql=(
                    f"{_NET_REVENUE_CTES} SELECT c.region, "
                    "ROUND(SUM(paid.paid_amount - COALESCE(refunded.refund_amount, 0)), "
                    "2) AS net_revenue FROM paid JOIN customers AS c "
                    "ON c.customer_id = paid.customer_id LEFT JOIN refunded "
                    "ON refunded.order_id = paid.order_id GROUP BY c.region "
                    "ORDER BY net_revenue DESC"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="bar",
                    title="Net revenue by region",
                    x_field="region",
                    y_field="net_revenue",
                ),
            )
        if "total" in text and "revenue" in text:
            return SQLPlan(
                intent="Total net revenue",
                relevant_tables=["orders", "payments", "refunds"],
                sql=(
                    f"{_NET_REVENUE_CTES} SELECT ROUND(SUM(paid.paid_amount - "
                    "COALESCE(refunded.refund_amount, 0)), 2) AS net_revenue "
                    "FROM paid LEFT JOIN refunded "
                    "ON refunded.order_id = paid.order_id"
                ),
                chart_suggestion=ChartSuggestion(
                    chart_type="kpi",
                    title="Total net revenue",
                    y_field="net_revenue",
                ),
            )
        return SQLPlan(
            intent="Request needs clarification in simulation mode",
            clarification_question=(
                "The simulator supports revenue, customers, products, orders, refunds, "
                "and explicit failure scenarios. Which one would you like to test?"
            ),
        )
