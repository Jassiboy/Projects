"""Provide deterministic local substitutes for the external LLM and database."""

from .fake_database import FakeDatabaseAdapter
from .fake_llm import FakeLLMProvider

__all__ = ["FakeDatabaseAdapter", "FakeLLMProvider"]
