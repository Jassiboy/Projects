"""Expose bounded sanitized traces to the local development interface."""

import os
import re

from fastapi import APIRouter, HTTPException, status

from backend.app.observability import get_trace


router = APIRouter()


@router.get("/traces/{trace_id}")
def read_analysis_trace(trace_id: str) -> dict:
    """Return one sanitized trace in development and hide the endpoint in production."""
    if os.getenv("APP_ENV", "development").casefold() == "production":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    if not re.fullmatch(r"[0-9a-fA-F]{32}", trace_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    events = get_trace(trace_id.casefold())
    if events is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Trace is unavailable or has expired.",
        )
    return {"trace_id": trace_id.casefold(), "events": events}
