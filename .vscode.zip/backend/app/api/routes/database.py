"""Create temporary sessions for real MySQL or the local learning simulator."""

from secrets import token_urlsafe

from fastapi import APIRouter, HTTPException, Request, status

from backend.app.config import (
    DatabaseSettings,
    SimulationSettings,
    simulation_available,
    simulation_mode_enabled,
)
from backend.app.database.base import DatabaseAdapter, DatabaseError
from backend.app.database.mysql import MySQLReadOnlyAdapter
from backend.app.dependencies import run_with_request_timeout
from backend.app.schemas.api import (
    DatabaseConnectRequest,
    DatabaseConnectResponse,
    SimulationModeResponse,
)
from backend.app.simulation.fake_database import FakeDatabaseAdapter


router = APIRouter()


def _store_session(
    request: Request,
    adapter: DatabaseAdapter,
    settings: DatabaseSettings,
) -> str:
    """Store one in-memory connection session and return its opaque identifier."""
    connection_id = token_urlsafe(32)
    sessions = getattr(request.app.state, "database_sessions", None)
    if sessions is None:
        sessions = {}
        request.app.state.database_sessions = sessions
    sessions[connection_id] = {"adapter": adapter, "settings": settings}
    return connection_id


@router.get("/database/mode", response_model=SimulationModeResponse)
def database_mode() -> SimulationModeResponse:
    """Tell the UI whether the development-only simulator can be selected."""
    return SimulationModeResponse(
        available=simulation_available(),
        default_enabled=simulation_mode_enabled(),
    )


@router.post(
    "/database/simulation/connect",
    response_model=DatabaseConnectResponse,
)
async def connect_simulation(request: Request) -> DatabaseConnectResponse:
    """Create a local fake database session without calling MySQL or an LLM."""
    if not simulation_available():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    settings = DatabaseSettings(
        DB_HOST="simulation",
        DB_USER="simulation",
        DB_PASSWORD="",
        DB_NAME=FakeDatabaseAdapter.database_name,
        DB_POOL_SIZE=1,
    )
    adapter = FakeDatabaseAdapter(
        latency_ms=min(SimulationSettings().latency_ms, 250)
    )
    tables = await run_with_request_timeout(request, adapter.list_tables)
    connection_id = _store_session(request, adapter, settings)
    return DatabaseConnectResponse(
        connection_id=connection_id,
        database=settings.database,
        table_count=len(tables),
        engine="Local simulation",
        simulation=True,
    )


@router.post("/database/connect", response_model=DatabaseConnectResponse)
async def connect_database(
    body: DatabaseConnectRequest,
    request: Request,
) -> DatabaseConnectResponse:
    """Validate credentials, open a read-only MySQL session, and return its identifier."""
    adapter: MySQLReadOnlyAdapter | None = None
    try:
        settings = DatabaseSettings(
            DB_HOST=body.host,
            DB_PORT=body.port,
            DB_USER=body.user,
            DB_PASSWORD=body.password.get_secret_value(),
            DB_NAME=body.database,
            DB_POOL_SIZE=2,
        )
        adapter = MySQLReadOnlyAdapter(settings)
        await run_with_request_timeout(request, adapter.health_check)
        tables = await run_with_request_timeout(request, adapter.list_tables)
    except (DatabaseError, TimeoutError, ValueError):
        if adapter is not None:
            adapter.close()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not connect with those database credentials.",
        ) from None

    connection_id = _store_session(request, adapter, settings)
    return DatabaseConnectResponse(
        connection_id=connection_id,
        database=settings.database,
        table_count=len(tables),
        engine="MySQL",
        simulation=False,
    )
