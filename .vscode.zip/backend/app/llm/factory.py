"""Create the configured provider-neutral LLM implementation."""

from backend.app.config import LLMSettings, SimulationSettings, simulation_mode_enabled

from .base import LLMConfigurationError, LLMProvider
from .gemini import GeminiProvider


def create_llm_provider(
    settings: LLMSettings | None = None,
    simulation_settings: SimulationSettings | None = None,
) -> LLMProvider:
    """Create the configured real provider or the deterministic local simulator."""
    simulation = simulation_settings or SimulationSettings()
    use_simulation = simulation_mode_enabled() or (
        simulation_settings is not None and simulation.enabled
    )
    if use_simulation:
        from backend.app.simulation.fake_llm import FakeLLMProvider

        return FakeLLMProvider(latency_ms=simulation.latency_ms)

    configuration = settings or LLMSettings()
    provider_name = configuration.provider.strip().casefold()
    if provider_name == "gemini":
        return GeminiProvider(configuration)
    if provider_name in {"openai", "claude"}:
        raise LLMConfigurationError(
            f"LLM provider '{provider_name}' is not implemented"
        )
    raise LLMConfigurationError(
        f"Unknown LLM provider '{provider_name or '<empty>'}'"
    )
