"""Write privacy-conscious structured traces for backend analysis requests."""

from contextvars import ContextVar, Token
from collections import OrderedDict
from datetime import UTC, datetime
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
from threading import Lock
from typing import Any
from uuid import uuid4


DEFAULT_LOG_PATH = Path(__file__).resolve().parents[1] / "logs" / "analysis.jsonl"
_TRACE_ID: ContextVar[str] = ContextVar("analysis_trace_id", default="unbound")
_LOGGER = logging.getLogger("analyst_ai.observability")
_TRACE_LOCATION_LOGGER = logging.getLogger("analyst_ai.trace_location")
_SENSITIVE_KEY_PARTS = ("password", "secret", "credential", "api_key", "authorization")
_TRACE_STORE: OrderedDict[str, list[dict[str, Any]]] = OrderedDict()
_TRACE_STORE_LOCK = Lock()
_MAX_IN_MEMORY_TRACES = 200
_MAX_EVENTS_PER_TRACE = 100
_TRACE_FILE_LOCK = Lock()
_STARTED_TRACE_FILES: set[str] = set()
_ACTIVE_LOG_PATH: Path | None = None


def configure_observability(log_path: Path | None = None) -> Path:
    """Configure one rotating JSON-lines file handler and return its path."""
    global _ACTIVE_LOG_PATH
    if log_path is not None:
        resolved_path = Path(log_path)
    elif _ACTIVE_LOG_PATH is not None:
        resolved_path = _ACTIVE_LOG_PATH
    else:
        resolved_path = Path(os.getenv("ANALYSIS_LOG_PATH", str(DEFAULT_LOG_PATH)))
    _ACTIVE_LOG_PATH = resolved_path
    resolved_path.parent.mkdir(parents=True, exist_ok=True)
    handler_key = str(resolved_path.resolve())
    if not any(getattr(handler, "analysis_log_path", None) == handler_key for handler in _LOGGER.handlers):
        handler = RotatingFileHandler(
            resolved_path,
            maxBytes=5_000_000,
            backupCount=3,
            encoding="utf-8",
        )
        handler.analysis_log_path = handler_key  # type: ignore[attr-defined]
        handler.setFormatter(logging.Formatter("%(message)s"))
        _LOGGER.addHandler(handler)
    _LOGGER.setLevel(logging.INFO)
    _LOGGER.propagate = False
    if not _TRACE_LOCATION_LOGGER.handlers:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter("[analysis-trace] %(message)s"))
        _TRACE_LOCATION_LOGGER.addHandler(console_handler)
    _TRACE_LOCATION_LOGGER.setLevel(logging.INFO)
    _TRACE_LOCATION_LOGGER.propagate = False
    return resolved_path


def new_trace_id() -> str:
    """Create and return a short opaque identifier for one backend request."""
    return uuid4().hex


def bind_trace(trace_id: str) -> Token[str]:
    """Bind a trace identifier to the current async or worker-thread context."""
    return _TRACE_ID.set(trace_id)


def reset_trace(token: Token[str]) -> None:
    """Restore the trace context that existed before the current request."""
    _TRACE_ID.reset(token)


def current_trace_id() -> str:
    """Return the trace identifier bound to the current execution context."""
    return _TRACE_ID.get()


def sql_fingerprint(sql: str) -> str:
    """Return a stable fingerprint without writing raw SQL or literal values."""
    normalized = " ".join(sql.split()).casefold()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def capture_llm_payloads_enabled() -> bool:
    """Return whether exact application prompts and structured outputs may be traced."""
    configured = os.getenv("OBSERVABILITY_CAPTURE_LLM_PAYLOADS")
    if configured is not None:
        return configured.casefold() in {"1", "true", "yes", "on"}
    return os.getenv("APP_ENV", "development").casefold() != "production"


def log_event(event: str, **fields: Any) -> None:
    """Append one sanitized structured event to the active request trace."""
    configure_observability()
    record = {
        "timestamp": datetime.now(UTC).isoformat(),
        "trace_id": current_trace_id(),
        "event": event,
        **_sanitize_mapping(fields),
    }
    _remember_event(record)
    serialized_record = json.dumps(record, ensure_ascii=True, separators=(",", ":"))
    _LOGGER.info(serialized_record)
    _write_trace_event(record, serialized_record)


def get_trace(trace_id: str) -> list[dict[str, Any]] | None:
    """Return a copy of one development trace, or null when it is unavailable."""
    with _TRACE_STORE_LOCK:
        events = _TRACE_STORE.get(trace_id)
        if events is not None:
            return [dict(event) for event in events]
    path = trace_log_path(trace_id)
    if not path.exists():
        return None
    loaded_events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            loaded_events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return loaded_events or None


def trace_log_path(trace_id: str) -> Path:
    """Return the individual JSONL path for one valid opaque trace identifier."""
    if not re.fullmatch(r"[0-9a-fA-F]{32}", trace_id):
        raise ValueError("trace_id must contain exactly 32 hexadecimal characters")
    consolidated_path = _ACTIVE_LOG_PATH or Path(
        os.getenv("ANALYSIS_LOG_PATH", str(DEFAULT_LOG_PATH))
    )
    return consolidated_path.parent / "traces" / f"{trace_id.casefold()}.jsonl"


def _write_trace_event(record: dict[str, Any], serialized_record: str) -> None:
    """Append analysis events to one trace-specific JSONL and announce its location once."""
    trace_id = str(record["trace_id"])
    if not re.fullmatch(r"[0-9a-fA-F]{32}", trace_id):
        return
    with _TRACE_FILE_LOCK:
        if trace_id not in _STARTED_TRACE_FILES:
            if str(record["event"]).startswith("http.request."):
                return
            path = trace_log_path(trace_id)
            path.parent.mkdir(parents=True, exist_ok=True)
            buffered_events = get_trace(trace_id) or [record]
            with path.open("a", encoding="utf-8") as trace_file:
                for buffered_event in buffered_events:
                    trace_file.write(
                        json.dumps(
                            buffered_event,
                            ensure_ascii=True,
                            separators=(",", ":"),
                        )
                        + "\n"
                    )
            _STARTED_TRACE_FILES.add(trace_id)
            _TRACE_LOCATION_LOGGER.info(
                "trace_id=%s file=%s",
                trace_id,
                path.resolve(),
            )
            return
        path = trace_log_path(trace_id)
        with path.open("a", encoding="utf-8") as trace_file:
            trace_file.write(serialized_record + "\n")


def _remember_event(record: dict[str, Any]) -> None:
    """Keep a bounded in-memory copy so the development UI can inspect a trace."""
    trace_id = str(record["trace_id"])
    if trace_id == "unbound":
        return
    with _TRACE_STORE_LOCK:
        events = _TRACE_STORE.setdefault(trace_id, [])
        events.append(dict(record))
        del events[:-_MAX_EVENTS_PER_TRACE]
        _TRACE_STORE.move_to_end(trace_id)
        while len(_TRACE_STORE) > _MAX_IN_MEMORY_TRACES:
            _TRACE_STORE.popitem(last=False)


def _sanitize_mapping(fields: dict[str, Any]) -> dict[str, Any]:
    """Return JSON-safe fields with secret-like keys redacted and values bounded."""
    return {key: _sanitize_value(key, value) for key, value in fields.items()}


def _sanitize_value(key: str, value: Any) -> Any:
    """Redact sensitive keys and return a bounded JSON-safe representation."""
    if any(part in key.casefold() for part in _SENSITIVE_KEY_PARTS):
        return "[REDACTED]"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        payload_limit = int(os.getenv("OBSERVABILITY_MAX_PAYLOAD_CHARS", "100000"))
        limit = min(max(payload_limit, 1000), 250000) if key in {
            "prompt",
            "structured_response_json",
        } else 500
        return value[:limit]
    if isinstance(value, (list, tuple, set)):
        return [_sanitize_value(key, item) for item in list(value)[:50]]
    if isinstance(value, dict):
        return _sanitize_mapping({str(item_key): item for item_key, item in value.items()})
    return type(value).__name__
