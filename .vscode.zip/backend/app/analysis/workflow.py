"""Orchestrate planning, validation, execution, repair, grounding, and response construction."""

from dataclasses import dataclass

from sqlglot import exp
from sqlglot.errors import ParseError
from sqlglot.optimizer.scope import Scope, traverse_scope

from backend.app.catalog.models import SchemaCatalog
from backend.app.database.base import DatabaseError, QueryValidationError
from backend.app.database.safe_query_runner import SafeQueryResult, SafeQueryRunner
from backend.app.database.sql_validator import SQLValidator, parse_mysql_sql
from backend.app.llm.base import LLMRateLimitError, LLMTimeoutError
from backend.app.observability import log_event, sql_fingerprint
from backend.app.tools.policy import DeterministicToolPolicy, WorkflowAction
from backend.app.tools.toolset import AnalysisToolset

from .answer_builder import AnswerBuilder
from .chart_policy import ChartPolicy
from .models import (
    AnalysisResponse,
    AnalysisResult,
    ExecutionMetadata,
    SQLPlan,
)
from .planner import AnalysisPlanner


class AnalysisWorkflowError(RuntimeError):
    """A sanitized failure while producing an analysis response."""


class AnalysisWorkflowTimeoutError(AnalysisWorkflowError):
    """An upstream analysis dependency exceeded its timeout."""


class AnalysisWorkflowRateLimitError(AnalysisWorkflowError):
    """An upstream analysis provider rate limit was reached."""


@dataclass(frozen=True)
class PlanValidation:
    """Represent PlanValidation data or behavior used by the application."""
    normalized_sql: str | None
    rejection_reason: str | None


class AnalysisWorkflow:
    """Coordinate the complete question-to-verified-analysis lifecycle."""
    def __init__(
        self,
        planner: AnalysisPlanner,
        validator: SQLValidator | None = None,
        query_runner: SafeQueryRunner | None = None,
        answer_builder: AnswerBuilder | None = None,
        chart_policy: ChartPolicy | None = None,
        row_limit: int = 100,
        *,
        tools: AnalysisToolset | None = None,
        tool_policy: DeterministicToolPolicy | None = None,
    ) -> None:
        """Initialize the core workflow with controlled tools and Python policy."""
        if row_limit < 1:
            raise ValueError("row_limit must be greater than zero")
        if tools is None:
            if validator is None or query_runner is None or answer_builder is None:
                raise ValueError(
                    "validator, query_runner, and answer_builder are required "
                    "when tools is not supplied"
                )
            tools = AnalysisToolset(
                validator=validator,
                query_runner=query_runner,
                answer_builder=answer_builder,
                chart_policy=chart_policy or ChartPolicy(),
            )
        self._planner = planner
        self._tools = tools
        self._tool_policy = tool_policy or DeterministicToolPolicy()
        self._row_limit = row_limit

    def analyze(
        self,
        question: str,
        catalog: SchemaCatalog,
        business_glossary: str = "",
    ) -> AnalysisResponse:
        """Process a natural-language question and return a validated analysis response."""
        schema_json = catalog.to_json()
        log_event(
            "analysis.started",
            question_length=len(question),
            catalog_table_count=len(catalog.tables),
            catalog_relationship_count=len(catalog.relationships),
        )
        log_event("planner.started")
        try:
            plan = self._planner.plan(question, schema_json, business_glossary)
        except LLMTimeoutError:
            log_event("planner.failed", error_code="LLM_TIMEOUT")
            raise AnalysisWorkflowTimeoutError(
                "The analysis provider timed out. Please try again."
            ) from None
        except LLMRateLimitError:
            log_event("planner.failed", error_code="LLM_RATE_LIMIT")
            raise AnalysisWorkflowRateLimitError(
                "The analysis provider is temporarily rate limited."
            ) from None
        except Exception:
            log_event("planner.failed", error_code="PLANNER_ERROR")
            raise AnalysisWorkflowError(
                "Analysis could not be planned. Please try again."
            ) from None
        if not isinstance(plan, SQLPlan):
            log_event("planner.failed", error_code="INVALID_PLAN_TYPE")
            raise AnalysisWorkflowError(
                "Analysis could not be planned. Please try again."
            )

        log_event(
            "planner.completed",
            relevant_tables=plan.relevant_tables,
            has_sql=bool(plan.sql.strip()),
            sql_fingerprint=sql_fingerprint(plan.sql) if plan.sql.strip() else None,
            needs_clarification=bool(plan.clarification_question),
            has_direct_answer=plan.direct_answer is not None,
        )
        decision = self._tool_policy.decide(plan)
        log_event("policy.selected", action=decision.action.value, reason=decision.reason)
        if decision.action is WorkflowAction.ASK_CLARIFICATION:
            log_event("analysis.completed", outcome="clarification")
            return self._clarification_response(plan)
        if decision.action is WorkflowAction.RETURN_DIRECT:
            log_event("analysis.completed", outcome="direct_answer")
            return AnalysisResponse(
                answer=plan.direct_answer or "",
                assumptions=list(plan.assumptions),
            )
        if decision.action is WorkflowAction.REJECT:
            log_event("analysis.rejected", error_code="NO_SAFE_ACTION")
            return self._rejected_response(plan.assumptions, decision.reason)
        return self._execute_plan(
            question,
            catalog,
            plan,
            schema_json,
            business_glossary,
            allow_repair=True,
        )

    def rerun_with_sql(
        self,
        question: str,
        catalog: SchemaCatalog,
        edited_sql: str,
        assumptions: list[str] | None = None,
    ) -> AnalysisResponse:
        """Perform rerun with sql and return the resulting application value."""
        log_event(
            "edited_sql.started",
            sql_fingerprint=sql_fingerprint(edited_sql),
            question_length=len(question),
        )
        validation_result = self._tools.validate_sql(
            edited_sql,
            self._row_limit,
        )
        if not validation_result.is_valid:
            log_event(
                "sql.validation.failed",
                error_code="EDITED_SQL_READ_ONLY_REJECTED",
                rejection_reason=validation_result.rejection_reason,
                sql_fingerprint=sql_fingerprint(edited_sql),
            )
            return self._rejected_response(
                assumptions or [],
                "Edited SQL was rejected by the read-only validator.",
            )
        referenced_tables = tuple(
            table.rsplit(".", 1)[-1]
            for table in validation_result.referenced_tables
        )
        plan = SQLPlan(
            intent=question[:500] or "User-edited query",
            relevant_tables=list(referenced_tables),
            sql=edited_sql,
            assumptions=assumptions or [],
        )
        validation = self._validate_plan(plan, catalog)
        if validation.rejection_reason:
            log_event("edited_sql.rejected", rejection_reason=validation.rejection_reason)
            return self._rejected_response(
                plan.assumptions,
                validation.rejection_reason,
            )
        return self._execute_validated_plan(
            question,
            plan,
            validation.normalized_sql or "",
        )

    def _execute_plan(
        self,
        question: str,
        catalog: SchemaCatalog,
        plan: SQLPlan,
        schema_json: str,
        business_glossary: str,
        allow_repair: bool,
    ) -> AnalysisResponse:
        """Execute plan and return its bounded result."""
        validation = self._validate_plan(plan, catalog)
        if validation.rejection_reason:
            log_event(
                "analysis.rejected",
                error_code="SQL_PLAN_VALIDATION_FAILED",
                rejection_reason=validation.rejection_reason,
                sql_fingerprint=sql_fingerprint(plan.sql),
            )
            return self._rejected_response(plan.assumptions, validation.rejection_reason)

        try:
            return self._execute_validated_plan(
                question,
                plan,
                validation.normalized_sql or "",
            )
        except (DatabaseError, QueryValidationError):
            if not allow_repair:
                return self._rejected_response(
                    plan.assumptions,
                    "Query could not be safely executed.",
                )

        log_event("repair.started", attempt=2)
        try:
            repaired_plan = self._planner.repair(
                question,
                schema_json,
                plan,
                "The read-only query execution failed.",
                business_glossary,
            )
        except LLMTimeoutError:
            log_event("repair.failed", error_code="LLM_TIMEOUT", attempt=2)
            raise AnalysisWorkflowTimeoutError(
                "The analysis provider timed out. Please try again."
            ) from None
        except LLMRateLimitError:
            log_event("repair.failed", error_code="LLM_RATE_LIMIT", attempt=2)
            raise AnalysisWorkflowRateLimitError(
                "The analysis provider is temporarily rate limited."
            ) from None
        except Exception:
            log_event("repair.failed", error_code="REPAIR_ERROR", attempt=2)
            return self._rejected_response(
                plan.assumptions,
                "The query failed and could not be safely repaired.",
            )
        if not isinstance(repaired_plan, SQLPlan):
            log_event("repair.failed", error_code="INVALID_REPAIRED_PLAN", attempt=2)
            return self._rejected_response(
                plan.assumptions,
                "The query failed and could not be safely repaired.",
            )
        if repaired_plan.clarification_question:
            log_event("repair.completed", outcome="clarification", attempt=2)
            return self._clarification_response(repaired_plan)

        log_event(
            "repair.completed",
            outcome="sql_plan",
            attempt=2,
            relevant_tables=repaired_plan.relevant_tables,
            sql_fingerprint=sql_fingerprint(repaired_plan.sql),
        )
        repaired_validation = self._validate_plan(repaired_plan, catalog)
        if repaired_validation.rejection_reason:
            log_event(
                "analysis.rejected",
                error_code="REPAIRED_SQL_VALIDATION_FAILED",
                rejection_reason=repaired_validation.rejection_reason,
                attempt=2,
            )
            return self._rejected_response(
                repaired_plan.assumptions,
                repaired_validation.rejection_reason,
                attempts=2,
            )
        try:
            return self._execute_validated_plan(
                question,
                repaired_plan,
                repaired_validation.normalized_sql or "",
                attempts=2,
            )
        except (DatabaseError, QueryValidationError):
            return self._rejected_response(
                repaired_plan.assumptions,
                "Query could not be safely executed after one repair attempt.",
                attempts=2,
            )

    def _execute_validated_plan(
        self,
        question: str,
        plan: SQLPlan,
        validated_sql: str,
        attempts: int = 1,
    ) -> AnalysisResponse:
        """Execute validated plan and return its bounded result."""
        log_event(
            "query.started",
            attempt=attempts,
            row_limit=self._row_limit,
            sql_fingerprint=sql_fingerprint(validated_sql),
        )
        try:
            query_result = self._tools.execute_sql(validated_sql, self._row_limit)
        except (DatabaseError, QueryValidationError) as error:
            log_event(
                "query.failed",
                error_code="QUERY_EXECUTION_FAILED",
                error_type=type(error).__name__,
                attempt=attempts,
            )
            raise
        log_event(
            "query.completed",
            attempt=attempts,
            row_count=query_result.row_count,
            truncated=query_result.truncated,
            execution_time_ms=round(query_result.execution_time * 1000, 3),
            result_columns=query_result.columns,
        )
        chart_spec = self._tools.choose_chart(
            plan,
            query_result.columns,
            query_result.rows,
        )
        log_event("answer.started", attempt=attempts, chart_type=chart_spec.chart_type)
        try:
            answer_result = self._tools.build_answer(
                question,
                plan,
                query_result.executed_sql,
                query_result.rows,
                chart_spec,
            )
        except LLMTimeoutError:
            log_event("answer.failed", error_code="LLM_TIMEOUT", attempt=attempts)
            raise AnalysisWorkflowTimeoutError(
                "The analysis provider timed out. Please try again."
            ) from None
        except LLMRateLimitError:
            log_event("answer.failed", error_code="LLM_RATE_LIMIT", attempt=attempts)
            raise AnalysisWorkflowRateLimitError(
                "The analysis provider is temporarily rate limited."
            ) from None
        except Exception:
            log_event("answer.failed", error_code="GROUNDING_OR_PROVIDER_ERROR", attempt=attempts)
            raise AnalysisWorkflowError(
                "The query completed, but its result could not be summarized safely."
            ) from None

        warnings = list(dict.fromkeys((*answer_result.warnings, *plan.assumptions)))
        if query_result.truncated:
            warnings.append("The query result was truncated to the requested row limit.")
        log_event(
            "analysis.completed",
            outcome="query_answer",
            attempt=attempts,
            chart_type=chart_spec.chart_type,
            row_count=query_result.row_count,
        )
        return self._response_from_result(
            answer_result,
            query_result,
            warnings,
            attempts,
        )

    def _validate_plan(self, plan: SQLPlan, catalog: SchemaCatalog) -> PlanValidation:
        """Validate plan and return the policy result."""
        if not plan.sql.strip():
            log_event("sql.validation.failed", error_code="SQL_MISSING")
            return PlanValidation(None, "Planner did not provide SQL.")
        table_names = {table.name.casefold() for table in catalog.tables}
        unknown_tables = sorted(
            {name.casefold() for name in plan.relevant_tables} - table_names
        )
        if unknown_tables:
            log_event(
                "sql.validation.failed",
                error_code="UNKNOWN_RELEVANT_TABLE",
                unknown_tables=unknown_tables,
                sql_fingerprint=sql_fingerprint(plan.sql),
            )
            return PlanValidation(
                None,
                "Planner referenced tables absent from the schema catalog.",
            )

        validation = self._tools.validate_sql(plan.sql, self._row_limit)
        if not validation.is_valid or validation.normalized_sql is None:
            log_event(
                "sql.validation.failed",
                error_code="READ_ONLY_POLICY_REJECTED",
                rejection_reason=validation.rejection_reason,
                sql_fingerprint=sql_fingerprint(plan.sql),
            )
            return PlanValidation(None, "SQL was rejected by the read-only validator.")
        try:
            statements, _ = parse_mysql_sql(validation.normalized_sql)
        except ParseError:
            log_event(
                "sql.validation.failed",
                error_code="SQL_PARSE_FAILED",
                sql_fingerprint=sql_fingerprint(plan.sql),
            )
            return PlanValidation(None, "SQL was rejected by the schema validator.")
        identifiers = sorted(
            {column.sql(dialect="mysql") for column in statements[0].find_all(exp.Column)}
        )
        if (
            len(statements) != 1
            or not self._tables_exist(statements[0], catalog)
            or not self._columns_exist(statements[0], catalog)
        ):
            log_event(
                "sql.validation.failed",
                error_code="SCHEMA_REFERENCE_NOT_FOUND",
                referenced_identifiers=identifiers,
                sql_fingerprint=sql_fingerprint(validation.normalized_sql),
            )
            return PlanValidation(
                None,
                "SQL referenced a table or column absent from the schema catalog.",
            )
        log_event(
            "sql.validation.completed",
            referenced_identifiers=identifiers,
            referenced_tables=list(validation.referenced_tables),
            sql_fingerprint=sql_fingerprint(validation.normalized_sql),
        )
        return PlanValidation(validation.normalized_sql, None)

    @staticmethod
    def _tables_exist(statement: exp.Expression, catalog: SchemaCatalog) -> bool:
        """Return whether tables exist satisfies the required condition."""
        known_tables = {table.name.casefold() for table in catalog.tables}
        referenced_tables = {
            source.name.casefold()
            for scope in traverse_scope(statement)
            for _, source in scope.sources.items()
            if isinstance(source, exp.Table)
        }
        return referenced_tables.issubset(known_tables)

    @staticmethod
    def _columns_exist(statement: exp.Expression, catalog: SchemaCatalog) -> bool:
        """Return whether columns exist satisfies the required condition."""
        columns_by_table = {
            table.name.casefold(): {column.name.casefold() for column in table.columns}
            for table in catalog.tables
        }
        all_columns = set().union(*columns_by_table.values()) if columns_by_table else set()
        for scope in traverse_scope(statement):
            output_aliases = {
                projection.alias.casefold()
                for projection in scope.expression.selects
                if isinstance(projection, exp.Alias)
            }
            sources = scope.selected_sources
            for column in scope.columns:
                if column.is_star:
                    continue
                name = column.name.casefold()
                if name in output_aliases:
                    continue
                if column.table:
                    selected_source = sources.get(column.table.casefold())
                    source = selected_source[1] if selected_source else None
                    if selected_source is None:
                        source = next(
                            (
                                candidate
                                for _, (_, candidate) in sources.items()
                                if isinstance(candidate, exp.Table)
                                and candidate.name.casefold() == column.table.casefold()
                            ),
                            None,
                        )
                    if isinstance(source, exp.Table):
                        source_columns = columns_by_table.get(source.name.casefold())
                        if source_columns is not None and name not in source_columns:
                            return False
                        if source_columns is None and name not in all_columns:
                            return False
                    elif isinstance(source, Scope):
                        source_outputs = {
                            output_name
                            for projection in source.expression.selects
                            if (
                                output_name
                                := AnalysisWorkflow._projection_output_name(projection)
                            )
                        }
                        if name not in source_outputs and name not in all_columns:
                            return False
                    elif name not in all_columns:
                        return False
                elif name not in all_columns:
                    return False
        return True

    @staticmethod
    def _projection_output_name(projection: exp.Expression) -> str | None:
        """Internal helper that performs projection output name and returns the normalized result."""
        if isinstance(projection, exp.Alias):
            return projection.alias.casefold()
        if isinstance(projection, exp.Column):
            return projection.name.casefold()
        return None

    @staticmethod
    def _response_from_result(
        result: AnalysisResult,
        query_result: SafeQueryResult,
        warnings: list[str],
        attempts: int,
    ) -> AnalysisResponse:
        """Internal helper that performs rejected response and returns the normalized result."""
        return AnalysisResponse(
            answer=result.explanation,
            sql=query_result.executed_sql,
            columns=query_result.columns,
            rows=query_result.rows,
            chart=result.chart_spec,
            assumptions=list(result.warnings),
            warnings=warnings,
            execution_metadata=ExecutionMetadata(
                row_count=query_result.row_count,
                execution_time_seconds=query_result.execution_time,
                truncated=query_result.truncated,
                attempts=attempts,
            ),
        )

    @staticmethod
    def _clarification_response(plan: SQLPlan) -> AnalysisResponse:
        """Internal helper that performs clarification response and returns the normalized result."""
        return AnalysisResponse(
            answer=plan.clarification_question or "Please clarify your question.",
            needs_clarification=True,
            clarification_question=plan.clarification_question,
            assumptions=list(plan.assumptions),
        )

    @staticmethod
    def _rejected_response(
        assumptions: list[str],
        warning: str,
        attempts: int = 1,
    ) -> AnalysisResponse:
        """Internal helper that performs response from result and returns the normalized result."""
        return AnalysisResponse(
            answer="The request could not be safely completed.",
            assumptions=list(assumptions),
            warnings=[warning],
            execution_metadata=ExecutionMetadata(
                row_count=0,
                execution_time_seconds=0,
                truncated=False,
                attempts=attempts,
            ),
        )
