"""Print the supported local-simulation prompts and exercised behavior."""

from pathlib import Path


README_PATH = Path(__file__).resolve().parents[1] / "app" / "simulation" / "README.md"


def main() -> None:
    """Print the versioned simulation guide to the terminal."""
    print(README_PATH.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
