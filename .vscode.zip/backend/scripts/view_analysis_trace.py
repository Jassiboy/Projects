"""Print recent sanitized backend trace events for local development diagnosis."""

import argparse
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.app.observability import DEFAULT_LOG_PATH


def load_events(path: Path) -> list[dict]:
    """Read valid JSON-line events from the observability log and return them."""
    if not path.exists():
        return []
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return events


def main() -> None:
    """Filter recent events by trace ID and print a readable execution timeline."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace-id", help="Show only this complete or prefix trace ID")
    parser.add_argument("--last", type=int, default=50, help="Maximum events to print")
    parser.add_argument("--log-path", type=Path, default=DEFAULT_LOG_PATH)
    args = parser.parse_args()
    if args.trace_id:
        matches = sorted(
            args.log_path.parent.joinpath("traces").glob(
                f"{args.trace_id.casefold()}*.jsonl"
            )
        )
        if len(matches) == 1:
            source_path = matches[0]
            events = load_events(source_path)
        else:
            source_path = args.log_path
            events = [
                event for event in load_events(source_path)
                if str(event.get("trace_id", "")).startswith(args.trace_id.casefold())
            ]
    else:
        source_path = args.log_path
        events = load_events(source_path)
    print(f"Trace source: {source_path.resolve()}")
    for event in events[-max(args.last, 1):]:
        details = {
            key: value
            for key, value in event.items()
            if key not in {"timestamp", "trace_id", "event"}
        }
        print(
            f"{event.get('timestamp', '')}  {event.get('trace_id', '')[:12]}  "
            f"{event.get('event', '')}  {json.dumps(details, ensure_ascii=True)}"
        )


if __name__ == "__main__":
    main()
