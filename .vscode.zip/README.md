# Data Analyst AI

A learning-focused, accuracy-first analytics assistant that turns natural-language questions into safe, explainable database analysis.

The application currently supports:

- A real read-only MySQL connection.
- A fully local fake LLM and in-memory fake database for learning and testing.
- Natural-language planning through a provider-neutral LLM interface.
- Deterministic Python policy for clarification, direct answers, query execution, and rejection.
- Read-only SQL validation, schema validation, bounded execution, and one controlled repair attempt.
- Grounded narrative answers, editable SQL, result tables, and conditional charts.
- Per-request observability with trace IDs, execution stages, and per-trace JSONL files.
- A continuous chat-style frontend with a Live/Simulation switch.

> This is a controlled hybrid system. It is not a free-form autonomous agent, and the LLM cannot directly select or execute arbitrary tools.

---

## 1. Architecture at a glance

```mermaid
flowchart LR
    U["User"] --> UI["frontend/index.html"]
    UI --> API["FastAPI routes"]
    API --> DEP["dependencies.py"]

    DEP --> CAT["Catalog service"]
    CAT --> DBA["Database adapter"]
    DBA --> LIVE_DB[("MySQL")]
    DBA --> FAKE_DB[("Seeded in-memory SQLite")]

    DEP --> WF["AnalysisWorkflow"]
    WF --> PLAN["AnalysisPlanner"]
    PLAN --> LLM["LLMProvider"]
    LLM --> GEMINI["GeminiProvider"]
    LLM --> FAKE_LLM["FakeLLMProvider"]

    WF --> POLICY["DeterministicToolPolicy"]
    POLICY --> TOOLS["AnalysisToolset"]
    TOOLS --> VALIDATE["1. validate_sql"]
    TOOLS --> EXECUTE["2. execute_sql"]
    TOOLS --> CHART["3. choose_chart"]
    TOOLS --> ANSWER["4. build_answer"]

    VALIDATE --> RUNNER["SafeQueryRunner"]
    EXECUTE --> RUNNER
    RUNNER --> DBA
    CHART --> RESULT["AnalysisResponse"]
    ANSWER --> RESULT
    RESULT --> API
    API --> UI

    API -.-> OBS["Observability / JSONL traces"]
    WF -.-> OBS
    LLM -.-> OBS
    RUNNER -.-> OBS
```

### Main architectural principle

The LLM proposes a typed plan. Python remains in control.

```text
LLM:     Understand the question and propose an SQLPlan.
Python:  Validate the plan, select the allowed action, invoke tools, and enforce safety.
Database: Execute only bounded read-only SQL after validation.
LLM:     Explain already-returned rows, without executing anything.
```

This separation prevents an LLM response from:

- Inventing a tool name.
- Selecting a database by itself.
- Skipping SQL validation.
- Running write or DDL statements.
- Executing multiple statements.
- Bypassing row and timeout limits.
- Returning unsupported numerical claims without evidence.

---

## 2. Is tool calling implemented?

Yes, but it is **controlled application-level tool calling**, not Gemini/OpenAI native autonomous function calling.

The allow-listed tool boundary is [backend/app/tools/toolset.py](backend/app/tools/toolset.py). It exposes exactly four tools:

| # | Tool | Implementation used | Purpose | Result |
|---|---|---|---|---|
| 1 | `validate_sql(sql, row_limit)` | `SQLValidator` | Parse and enforce read-only/schema policy | `SQLValidationResult` |
| 2 | `execute_sql(sql, row_limit)` | `SafeQueryRunner` | Revalidate and run one bounded query | `SafeQueryResult` |
| 3 | `choose_chart(plan, columns, rows)` | `ChartPolicy` | Deterministically choose a safe visualization | `ChartSpec` |
| 4 | `build_answer(...)` | `AnswerBuilder` | Build and verify a narrative from returned rows | `AnalysisResult` |

The LLM does **not** call these tools. The core workflow calls them after [backend/app/tools/policy.py](backend/app/tools/policy.py) chooses one of four allowed actions:

| Policy action | Condition | Database queried? |
|---|---|---:|
| `ASK_CLARIFICATION` | `SQLPlan.clarification_question` is present | No |
| `RETURN_DIRECT` | A direct answer exists and SQL is empty | No |
| `EXECUTE_QUERY` | SQL is present | Only after validation |
| `REJECT` | The plan has no safe action | No |

The planner and adapters are important components, but they are not counted as analysis tools:

- `AnalysisPlanner` asks the LLM for a typed `SQLPlan`.
- `DatabaseAdapter` abstracts database metadata and query execution.
- `LLMProvider` abstracts structured model generation.

---

## 3. High-level request flow

When the user submits a prompt such as **“Give the revenue region-wise”**, the following happens:

1. The frontend creates a trace ID and immediately displays the user message.
2. The frontend starts the compact **Thinking / Analysis complete** timeline.
3. `POST /api/v1/analyze` receives `{"question": "..."}`.
4. Request middleware binds the trace ID and records request timing.
5. FastAPI/Pydantic validates the request contract.
6. Dependencies resolve the selected database session.
7. The catalog loader reads tables, columns, and relationships.
8. The catalog service enriches schema metadata with the business glossary.
9. The planner sends the question, catalog, and metric definitions to the selected LLM.
10. The LLM returns a strictly typed `SQLPlan`.
11. Deterministic Python policy selects clarification, direct answer, query, or rejection.
12. For a query plan, the workflow verifies relevant tables and referenced columns.
13. Tool 1 validates SQL and applies the row limit.
14. Tool 2 revalidates at the execution boundary and executes through the active adapter.
15. If the first database execution fails, the workflow permits one controlled LLM repair.
16. Tool 3 determines whether a bar, line, KPI, or table representation fits the rows.
17. Tool 4 asks the LLM to summarize bounded rows and verifies evidence/numeric claims.
18. The workflow builds an `AnalysisResponse`.
19. The API returns answer, SQL, rows, chart specification, warnings, and execution metadata.
20. The frontend conditionally renders only the available sections.
21. The completed trace remains expandable and the full event stream remains in JSONL.

---

## 4. Detailed execution sequence

```mermaid
sequenceDiagram
    actor User
    participant UI as frontend/index.html
    participant API as analysis.py route
    participant DI as dependencies.py
    participant Catalog as CatalogService
    participant Planner as AnalysisPlanner
    participant LLM as LLMProvider
    participant Policy as DeterministicToolPolicy
    participant Tools as AnalysisToolset
    participant DB as DatabaseAdapter
    participant Obs as Observability

    User->>UI: Enter natural-language question
    UI->>Obs: Supply X-Trace-ID
    UI->>API: POST /api/v1/analyze
    API->>DI: Resolve connection, catalog, workflow
    DI-->>API: Request-scoped services
    API->>Catalog: Build schema catalog
    Catalog->>DB: Load metadata
    DB-->>Catalog: Tables, columns, relationships
    Catalog-->>API: Enriched catalog + glossary
    API->>Planner: plan(question, catalog, glossary)
    Planner->>LLM: generate_structured(..., SQLPlan)
    LLM-->>Planner: Typed SQLPlan
    Planner-->>Policy: SQLPlan
    Policy-->>API: Allowed action

    alt Clarification required
        API-->>UI: Clarification, no SQL
    else Direct answer
        API-->>UI: Direct answer, no SQL
    else Rejected plan
        API-->>UI: Safe rejection, no SQL
    else Execute query
        API->>Tools: validate_sql
        Tools-->>API: Normalized SQL or rejection
        API->>Tools: execute_sql
        Tools->>DB: Bounded read-only query
        DB-->>Tools: Rows + metadata

        alt First execution fails
            API->>Planner: repair(previous plan, safe failure reason)
            Planner->>LLM: generate corrected SQLPlan
            LLM-->>Planner: Repaired SQLPlan
            API->>Tools: Validate again
            API->>Tools: Execute one final attempt
        end

        API->>Tools: choose_chart
        Tools-->>API: ChartSpec
        API->>Tools: build_answer
        Tools->>LLM: Explain bounded rows
        LLM-->>Tools: GroundedAnswer
        Tools-->>API: Verified AnalysisResult
        API-->>UI: AnalysisResponse
    end

    API->>Obs: Record safe stage events
    UI->>Obs: Poll development trace
    Obs-->>UI: Sanitized timeline
```

---

## 5. Branch behavior

### 5.1 Clarification branch

Example: `Show revenue`

The planner may determine that “revenue” could mean gross revenue or net revenue. It sets `clarification_question` and leaves SQL empty.

Result:

- Python selects `ASK_CLARIFICATION`.
- No SQL validation occurs.
- No database query occurs.
- The question is returned to the frontend.
- The next user message supplies the missing context.

### 5.2 Direct-answer branch

Example: `What does net revenue mean?`

The planner may return `direct_answer` with empty SQL.

Result:

- Python selects `RETURN_DIRECT`.
- No database query occurs.
- No chart or table is required.
- The frontend renders only text.

### 5.3 Query branch

Example: `Give the revenue region-wise`

The plan contains SQL and relevant tables.

Result:

- Python selects `EXECUTE_QUERY`.
- Schema references and SQL policy are validated.
- The bounded query is executed.
- Chart and table sections are based on returned data.
- Used SQL is always returned and remains editable.

### 5.4 Rejection branch

A plan is rejected when it has no safe action, or its SQL violates policy/schema rules.

Result:

- The query does not reach the database.
- The user receives a safe response and warning.
- Internal database/provider details are not exposed.

### 5.5 Controlled repair branch

A repair is attempted only when the first validated query reaches the database and execution fails.

1. The workflow records a safe failure reason.
2. The planner receives the original question, catalog, failed plan, and safe reason.
3. The LLM returns one corrected `SQLPlan`.
4. All catalog and SQL checks run again.
5. The repaired query receives one final execution attempt.
6. `execution_metadata.attempts` becomes `2` on success.

There is no unlimited agent loop. A second execution failure stops safely.

### 5.6 Edited-SQL rerun

When a user changes generated SQL and selects **Validate & run**:

1. The frontend sends the original question, edited SQL, and assumptions to `POST /api/v1/sql/run`.
2. The workflow does not ask the planner to regenerate SQL.
3. The edited statement passes through the same SQL and schema validation.
4. The same bounded execution tool runs it.
5. Chart and grounded answer are regenerated from the new rows.
6. The frontend replaces the previous report.

---

## 6. Live mode versus Simulation mode

The UI header contains a **Live / Simulation** switch.

### Live mode

- Database: `MySQLReadOnlyAdapter`
- LLM: `GeminiProvider`
- Credentials: submitted through the local database dialog
- Storage: credentials and adapter remain in backend memory for that server session
- External calls: MySQL and Gemini are used

### Simulation mode

- Database: `FakeDatabaseAdapter`
- Storage engine: deterministic, seeded, in-memory SQLite
- LLM: `FakeLLMProvider`
- Credentials: not required
- External calls: none
- All core workflow, policy, SQL validation, chart, answer, API, UI, and observability code remains active

The fake database exposes these seven production-shaped tables:

1. `categories`
2. `customers`
3. `products`
4. `orders`
5. `order_items`
6. `payments`
7. `refunds`

Simulation can also deliberately exercise:

- Direct answers.
- Clarification.
- Empty results.
- Unsafe SQL rejection.
- Database execution failure.
- One successful controlled repair.
- LLM rate limiting.
- LLM timeout.
- Invalid LLM output.

See [backend/app/simulation/README.md](backend/app/simulation/README.md) for the full prompt list.

---

## 7. Database abstraction

[backend/app/database/base.py](backend/app/database/base.py) defines the stable adapter contract:

```text
health_check()       -> bool
list_tables()        -> list[TableInfo]
get_table_schema()   -> TableSchema
execute_query(...)   -> QueryResult
close()              -> None
```

Additional catalog loading is supplied through `load_catalog_metadata()`.

Current adapters:

- [backend/app/database/mysql.py](backend/app/database/mysql.py) — real pooled MySQL reads.
- [backend/app/simulation/fake_database.py](backend/app/simulation/fake_database.py) — seeded in-memory learning database.

This boundary is where a future BigQuery or on-premises database adapter should be added. The workflow should not contain provider-specific connection logic.

---

## 8. LLM abstraction

[backend/app/llm/base.py](backend/app/llm/base.py) defines one provider-neutral operation:

```text
generate_structured(prompt, response_model) -> LLMResponse[response_model]
```

Current providers:

- [backend/app/llm/gemini.py](backend/app/llm/gemini.py) — real Gemini structured generation, retries, timeout/error mapping, and fallback model support.
- [backend/app/simulation/fake_llm.py](backend/app/simulation/fake_llm.py) — deterministic local plans, answers, and failure scenarios.

[backend/app/llm/factory.py](backend/app/llm/factory.py) selects the implementation. OpenAI and Claude names are recognized as future providers but are not implemented yet.

The LLM is used twice on the normal query path:

1. Planning: natural language + catalog -> `SQLPlan`.
2. Answering: bounded query rows -> `GroundedAnswer`.

It may be used a third time for the single controlled repair attempt.

---

## 9. SQL safety model

[backend/app/database/sql_validator.py](backend/app/database/sql_validator.py) uses SQL parsing rather than keyword-only string checks.

It enforces:

- Exactly one statement.
- Only `SELECT`, `WITH ... SELECT`, or `UNION`.
- No `INSERT`, `UPDATE`, `DELETE`, DDL, commands, or `USE`.
- No `SELECT INTO`.
- No locking query.
- No risky functions such as sleep, benchmark, or file loading.
- No system schemas.
- Only approved business tables.
- A bounded positive row limit.

The workflow adds schema-level checks:

- Every `relevant_table` must exist in the current catalog.
- Referenced tables must exist.
- Referenced columns must exist.
- CTE outputs and aliases are checked before execution.

[backend/app/database/safe_query_runner.py](backend/app/database/safe_query_runner.py) validates again at the execution boundary. This defense-in-depth step prevents a caller from bypassing the workflow-level check.

Current runtime bounds:

| Bound | Current value |
|---|---:|
| Shared API request deadline | 60 seconds |
| Database execution timeout | 5 seconds |
| Analysis result row limit | 100 |
| Maximum validator-supported limit | 1,000 |
| Rows sent to answer LLM | 50 |
| Repair attempts after initial failure | 1 |

---

## 10. Catalog and business semantics

[backend/app/catalog/metadata_loader.py](backend/app/catalog/metadata_loader.py) converts raw database metadata into typed catalog objects.

[backend/app/catalog/catalog_service.py](backend/app/catalog/catalog_service.py):

- Merges schema metadata with descriptions.
- Loads approved non-sensitive sample values.
- Prevents samples for sensitive columns.
- Loads business metric definitions.
- Produces deterministic catalog JSON for the planner.

[backend/app/catalog/business_glossary.yaml](backend/app/catalog/business_glossary.yaml) currently defines:

- Table descriptions.
- Column descriptions.
- Approved sample values.
- `net_revenue`.
- `refund_rate`.

Metric definitions belong here rather than being invented independently in prompts.

---

## 11. Chart and answer grounding

### Chart policy

[backend/app/analysis/chart_policy.py](backend/app/analysis/chart_policy.py) infers:

- Time field + numeric field -> line chart.
- Category field + numeric field -> bar chart.
- One numeric value -> KPI.
- Otherwise -> table.

An LLM chart suggestion is accepted only when its type matches the deterministic inference and its fields exist in the result.

### Answer grounding

[backend/app/analysis/answer_builder.py](backend/app/analysis/answer_builder.py):

1. Sends at most 50 result rows to the LLM.
2. Requests structured explanation, findings, and evidence.
3. Confirms every cited evidence value exists in supplied rows.
4. Confirms numerical claims correspond to values in supplied rows.
5. Fails closed if grounding checks fail.
6. Returns a deterministic “No rows matched” answer without calling the LLM for an empty result.

---

## 12. Observability

Every backend request receives a 32-character trace ID.

The frontend sends the same ID in `X-Trace-ID`, allowing the UI timeline and backend JSONL to refer to the same operation.

### Where traces are stored

- Combined rotating log: `backend/logs/analysis.jsonl`
- One file per analysis: `backend/logs/traces/<trace-id>.jsonl`
- Terminal: the backend prints the exact per-trace file location when analysis begins

The combined file rotates near 5 MB and keeps three backups.

### Typical event order

```text
http.request.started
catalog.started
catalog.completed
analysis.started
planner.started
llm.request.payload                 # development payload capture
llm.response.payload
planner.completed
policy.selected
sql.validation.completed
query.started
query.completed
answer.started
llm.request.payload
llm.response.payload
analysis.completed
http.request.completed
```

Failure or alternate events include:

- `planner.failed`
- `sql.validation.failed`
- `query.failed`
- `repair.started`
- `repair.completed`
- `repair.failed`
- `answer.failed`
- `analysis.rejected`
- `analysis.request.failed`

### Payload rules

During local development, traces can include:

- Exact application prompt sent to the LLM.
- Parsed structured LLM response.
- Generated SQL inside `structured_response_json`.
- Model, latency, token usage, and finish status.
- Validation decisions and execution metadata.

They never intentionally include:

- Database passwords.
- API keys.
- Authorization headers.
- Credentials.
- Private model chain-of-thought.

Disable full LLM payload capture with:

```env
OBSERVABILITY_CAPTURE_LLM_PAYLOADS=false
```

Inspect one trace:

```powershell
python backend/scripts/view_analysis_trace.py --trace-id <trace-id-prefix>
```

---

## 13. API reference

All APIs use the `/api/v1` prefix.

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/health` | Application and active database health |
| `GET` | `/database/mode` | Development simulation availability/default |
| `POST` | `/database/connect` | Create a temporary real MySQL session |
| `POST` | `/database/simulation/connect` | Create a fake database + fake LLM session |
| `POST` | `/analyze` | Natural-language analysis |
| `POST` | `/sql/run` | Revalidate and execute edited SQL |
| `GET` | `/traces/{trace_id}` | Read bounded development trace events |

Analysis requests use:

```text
X-Database-Connection: <opaque session ID>
X-Trace-ID: <32 hexadecimal characters>
```

The browser keeps these values only in page memory.

---

## 14. Important response models

### SQLPlan

```text
intent
direct_answer
relevant_tables
sql
assumptions
clarification_question
chart_suggestion
```

### AnalysisResponse

```text
answer
sql
columns
rows
chart
needs_clarification
clarification_question
assumptions
warnings
execution_metadata
```

### ExecutionMetadata

```text
row_count
execution_time_seconds
truncated
attempts
```

---

## 15. Script-by-script map

| File | Responsibility |
|---|---|
| `frontend/index.html` | Chat UI, database modal, Live/Simulation switch, trace timeline, answer/table/chart/SQL rendering, edited-SQL rerun |
| `backend/app/main.py` | FastAPI creation, middleware, frontend hosting, sanitized global errors, shutdown cleanup |
| `backend/app/api/router.py` | Registers versioned route groups |
| `backend/app/api/routes/database.py` | Real and simulated database sessions |
| `backend/app/api/routes/analysis.py` | Analyze and edited-SQL HTTP boundaries |
| `backend/app/api/routes/health.py` | Health endpoint |
| `backend/app/api/routes/observability.py` | Development trace lookup |
| `backend/app/dependencies.py` | Session resolution, provider/adapter assembly, caching, deadlines |
| `backend/app/config.py` | Environment-backed DB, LLM, and simulation settings |
| `backend/app/analysis/models.py` | Typed plan, chart, result, and response contracts |
| `backend/app/analysis/planner.py` | LLM planning and controlled repair prompts |
| `backend/app/analysis/workflow.py` | Core state machine/orchestration |
| `backend/app/analysis/chart_policy.py` | Deterministic chart choice |
| `backend/app/analysis/answer_builder.py` | Grounded result explanation |
| `backend/app/tools/policy.py` | Deterministic next-action selection |
| `backend/app/tools/toolset.py` | Four allow-listed analysis tools |
| `backend/app/database/base.py` | Database adapter interface and neutral errors |
| `backend/app/database/mysql.py` | Real read-only MySQL implementation |
| `backend/app/database/sql_validator.py` | Parsed SQL security policy |
| `backend/app/database/safe_query_runner.py` | Revalidation, timeout, and bounded execution |
| `backend/app/catalog/metadata_loader.py` | Raw metadata -> typed catalog |
| `backend/app/catalog/catalog_service.py` | Schema + glossary enrichment |
| `backend/app/catalog/business_glossary.yaml` | Metric and field semantics |
| `backend/app/llm/base.py` | Provider-neutral structured LLM interface |
| `backend/app/llm/factory.py` | Real/fake provider selection |
| `backend/app/llm/gemini.py` | Gemini implementation and provider error mapping |
| `backend/app/simulation/fake_llm.py` | Deterministic plans, answers, and failure scenarios |
| `backend/app/simulation/fake_database.py` | Seeded in-memory analytics database |
| `backend/app/observability.py` | Trace context, sanitization, rotation, per-trace JSONL |
| `backend/scripts/view_analysis_trace.py` | Terminal trace viewer |
| `backend/scripts/show_simulation_prompts.py` | Prints simulation guide/prompts |
| `backend/scripts/check_database.py` | Verifies local database connectivity and lists available tables |
| `backend/scripts/seed_database.py` | Creates deterministic sample commerce data and verifies seeded totals |
| `backend/tests/` | Unit, workflow, API, observability, and optional integration tests |

---

## 16. Project structure

```text
Data_analyst_ai/
├── README.md
├── PROJECT_ROADMAP_AND_ARCHITECTURE.md
├── .env
├── .env.example
├── requirements.txt
├── pytest.ini
├── frontend/
│   └── index.html
└── backend/
    ├── app/
    │   ├── main.py
    │   ├── config.py
    │   ├── dependencies.py
    │   ├── observability.py
    │   ├── analysis/
    │   ├── api/
    │   ├── catalog/
    │   ├── database/
    │   ├── llm/
    │   ├── simulation/
    │   └── tools/
    ├── logs/
    │   └── traces/
    ├── scripts/
    └── tests/
```

This working copy is intentionally Git-free; the application runs directly from this single project root.

---

## 17. Running the project

From the project root:

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn backend.app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

### Start in Simulation mode by default

Add to `.env`:

```env
SIMULATION_MODE=true
SIMULATION_LATENCY_MS=180
```

Or leave it false and use the UI switch:

```env
SIMULATION_MODE=false
```

### Start in Live mode

Required environment values:

```env
APP_ENV=development

DB_HOST=localhost
DB_PORT=3306
DB_USER=analyst_ai_readonly
DB_PASSWORD=<local read-only password>
DB_NAME=analyst_ai

LLM_PROVIDER=gemini
GEMINI_API_KEY=<local API key>
GEMINI_MODEL=gemini-flash-lite-latest
GEMINI_FALLBACK_MODEL=gemini-3.1-flash-lite
```

Do not commit the real `.env`.

---

## 18. Verification

Run all automated tests:

```powershell
python -m pytest -q
```

Current verified result when this README was generated:

```text
128 passed, 6 skipped
```

The skipped tests are optional integration tests that require real external services/configuration.

Useful simulation prompts:

```text
Give the revenue region-wise
Compare net revenue year by year
Show net revenue by sales channel
Show the top 5 products by sales
What does net revenue mean?
Show revenue
Show revenue for Antarctica
Simulate repair
Simulate unsafe SQL
Simulate database failure
Simulate rate limit
Simulate LLM timeout
Simulate invalid LLM
```

---

## 19. Current limitations

- MySQL is the only implemented real database adapter.
- Gemini is the only implemented real LLM provider.
- Conversation history is frontend memory only; it is not persisted.
- Connection sessions are backend memory only and do not yet have expiry/disconnect cleanup APIs.
- Progress is polled from development traces rather than streamed with SSE/WebSockets.
- SQL validation currently assumes the MySQL dialect and a fixed approved-table set.
- The answer is generated after the query completes; token-by-token narrative streaming is not implemented.
- Simulation is deterministic and intentionally covers known learning scenarios; it is not a general-purpose language model.

---

## 20. Safe extension points

### Add BigQuery

Implement a new `DatabaseAdapter` with:

- Health check.
- Dataset/table listing.
- Schema and relationship metadata.
- Dry-run byte estimation.
- Maximum bytes billed.
- Bounded execution and timeout/cancellation.
- Adapter contract tests.

Then make SQL dialect and approved-table policy adapter-aware. The workflow and four tools should remain unchanged.

### Add OpenAI or Claude

Implement `LLMProvider.generate_structured()`, map provider errors into neutral exceptions, add factory selection, and run provider contract tests. The planner, workflow, and tool policy should remain unchanged.

### Add a new capability/tool

1. Define a typed input and output contract.
2. Add the capability to `AnalysisToolset`.
3. Add a deterministic policy branch.
4. Invoke it from an explicit workflow state.
5. Add trace events.
6. Add unit and integration tests.
7. Do not expose unrestricted native tool calling merely to add the capability.

This preserves the central rule: **the LLM proposes; Python decides and executes.**
